package OA2;

public class Process {
	int arrTime;
	int exeTime;
	public Process(int arr, int exe) {
		arrTime = arr;
		exeTime = exe;
	}
}
