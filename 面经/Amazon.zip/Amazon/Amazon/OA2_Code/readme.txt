代码里的Point class是给 Round Robin Schedule 和 Shortest Job First用的，不过可以用一个数组代替。

Solution.java 是用来测试的，里面有测试用例。